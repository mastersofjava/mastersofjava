public class StartupUtil {

	public static void makeItWork(Server server) throws Exception {

	}
}

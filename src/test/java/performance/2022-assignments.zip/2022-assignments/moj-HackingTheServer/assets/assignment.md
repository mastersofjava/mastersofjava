# Fix the server

Please help! Our main build server is broken! Can you make it boot again?

As is quite common, we have used the oldest server we have as our build server. 
Years and years ago, some ex-employee set it up, somewhere in the building and it
was running fine for all that time. (Ok, developers complained that it was a bit
slow, but developers always complain). But now, it won't boot anymore. 
It complains about a missing boot device and I specifically remember buying an
expensive Seagate disk for this purpose. I hope it didn't fail!

Problem is, we don't know where it is (I think we moved it to the Cloud at some
point). We can still access it remotely though. Can you make it boot again and get
Hudson up and running? I think you may have to resort to some hacking but that's 
fine; it's just our build server.  

You don't know what Hudson is? That's the predecessor of Jenkins! What, you are 
used to using Gitlab pipelines? Well, get this thing running again, and maybe 
we'll find some budget to do something about this technical debt you dev's keep 
talking about. So I don't care about pretty code, or even maintainable code. Use whatever you need.


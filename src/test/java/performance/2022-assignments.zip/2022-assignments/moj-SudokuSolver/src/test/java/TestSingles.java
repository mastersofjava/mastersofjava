import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;

public class TestSingles {

    private RegionReducer regionReducer = new RegionReducer();

    /**
     * In this test the number 5 occurs only once, so all other numbers should be removed from that cell
     */
    @Test
    public void testOccursOnce() {
        List<List<Integer>> region = toList(new int[][]{{1, 2, 4, 6, 8, 9}, {1, 2, 4, 6, 8, 9}, {4, 6, 8, 9}, {7}, {1, 6, 8, 9}, {6, 8, 9}, {2, 4, 5, 8, 9}, {2, 4, 8, 9}, {3}});

        List<List<Integer>> reducedRegion = regionReducer.reduce(region);

        List<List<Integer>> expectedRegion = toList(new int[][]{{1, 2, 4, 6, 8, 9}, {1, 2, 4, 6, 8, 9}, {4, 6, 8, 9}, {7}, {1, 6, 8, 9}, {6, 8, 9}, {5}, {2, 4, 8, 9}, {3}});
        assertEquals(expectedRegion, reducedRegion);
    }

    /**
     * In this test the 9,8,7,6,5 and 4 are given and thus the last two cells can be simplified.
     */
    @Test
    public void testSingle() {
        List<List<Integer>> region = toList(new int[][]{{9}, {8}, {7}, {6}, {5}, {4}, {3}, {1, 2, 3, 4, 5, 6, 7, 8, 9}, {1, 2, 3, 4, 5, 6, 7, 8, 9}});

        List<List<Integer>> reducedRegion = regionReducer.reduce(region);

        List<List<Integer>> expectedRegion = toList(new int[][]{{9}, {8}, {7}, {6}, {5}, {4}, {3}, {1,2}, {1,2}});
        assertEquals(expectedRegion, reducedRegion);
    }

    private List<List<Integer>> toList(int[][] array) {
        return Stream.of(array).map(cell -> Arrays.stream(cell).boxed().toList()).toList();
    }
}

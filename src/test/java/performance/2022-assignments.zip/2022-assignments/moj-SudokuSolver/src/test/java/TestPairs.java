import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;

public class TestPairs {

    private RegionReducer regionReducer = new RegionReducer();

    /**
     * In this test there are 3 singles and 2 pairs that should be removed from the last two cells.
     */
    @Test
    public void testSinglesAndPairs() {
        List<List<Integer>> region = toList(new int[][]{{1}, {2, 3}, {2, 3}, {4, 5}, {4, 5}, {6}, {7}, {1, 2, 3, 4, 5, 6, 7, 8, 9}, {1, 2, 3, 4, 5, 6, 7, 8, 9}});

        List<List<Integer>> reducedRegion = regionReducer.reduce(region);

        List<List<Integer>> expectedRegion = toList(new int[][]{{1}, {2, 3}, {2, 3}, {4, 5}, {4, 5}, {6}, {7}, {8, 9}, {8, 9}});
        assertEquals(expectedRegion, reducedRegion);
    }

    private List<List<Integer>> toList(int[][] array) {
        return Stream.of(array).map(cell -> Arrays.stream(cell).boxed().toList()).toList();
    }
}

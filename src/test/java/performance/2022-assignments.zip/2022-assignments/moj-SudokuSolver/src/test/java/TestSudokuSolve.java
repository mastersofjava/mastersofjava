import org.junit.Ignore;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tests if we can actually solve a sudoku now
 */
public class TestSudokuSolve  {


    // This test requires you implemented reduction for single occurrences or for pairs
    @Test
    public void testRegionReducer() {
        RegionReducer regionReducer = new RegionReducer();
        List<List<Integer>> region = toList(new int[][]{{1}, {2}, {3}, {4, 5}, {4, 5}, {4, 5, 6}, {7}, {8}, {9}});

        List<List<Integer>> reducedRegion = regionReducer.reduce(region);

        List<List<Integer>> expectedRegion = toList(new int[][]{{1}, {2}, {3}, {4, 5}, {4, 5}, {6}, {7}, {8}, {9}});
        assertEquals(expectedRegion, reducedRegion);
    }

    // This test requires you implemented reduction for singles, pairs and triples, or singles and single occurrences
    @Test
    public void solveNotSoHard1() {
        Sudoku sudoku = new Sudoku(new Integer[][]{
                {1, null, null, null, null, 6, null, 3, 2},
                {2, null, 4, null, null, null, null, null, null},
                {null, null, 6, 2, null, null, null, null, 5},
                {null, null, 2, 5, null, 1, null, 8, null},
                {null, 3, null, null, 4, null, null, null, null},
                {5, null, null, 8, 2, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {7, null, null, 1, null, null, 4, 2, null},
                {null, null, null, null, 7, null, null, 6, 1}
        });
        SudokuSolver solver = new SudokuSolver();
        System.out.println("Initial: " + sudoku);
        Sudoku solvedSudoku = solver.solve(sudoku);
        System.out.println("Solved: " + solvedSudoku);
        assertTrue(solvedSudoku.isSolved());
    }

    @Ignore("This sudoku requires other solving methods, e.g reducing the 8 from one column of a block, because in the block below it can only be in that column")
    @Test
    public void solveHard1() {
        Sudoku sudoku = new Sudoku(new Integer[][]{
                {null, null, 5, 8, null, 2, null, 4, null},
                {null, 6, null, null, null, null, null, 8, null},
                {null, 1, null, 9, null, null, null, 2, null},
                {4, null, null, 7, null, null, null, 9, null},
                {null, null, null, null, null, null, null, null, null},
                {null, 5, null, 2, null, null, 1, null, null},
                {null, 7, null, 5, null, null, 3, null, null},
                {null, null, null, null, 8, 6, null, null, null},
                {null, null, 6, null, 7, null, 9, null, null}
        });
        SudokuSolver solver = new SudokuSolver();
        System.out.println("Initial: " + sudoku);
        Sudoku solvedSudoku = solver.solve(sudoku);
        System.out.println("Solved: " + solvedSudoku);
        assertTrue(solvedSudoku.isSolved());
    }

    @Ignore("This sudoku requires other solving methods, e.g reducing the 8 from one column of a block, because in the block above it can only be in that column")
    @Test
    public void solveHard2() {
        Sudoku sudoku = new Sudoku(new Integer[][]{
                {null, null, 5, 9, null, null, null, null, null},
                {null, null, 1, 6, null, null, null, 4, null},
                {null, 3, null, 7, null, null, 6, 9, null},
                {null, null, null, null, null, null, null, null, null},
                {7, null, null, 4, null, null, null, 2, null},
                {null, null, 3, null, null, 1, null, 6, null},
                {null, null, null, null, null, null, 5, null, 9},
                {null, null, 2, null, null, 8, null, 3, null},
                {null, 5, null, null, null, 4, null, null, 2}
        });
        SudokuSolver solver = new SudokuSolver();
        System.out.println("Initial: " + sudoku);
        Sudoku solvedSudoku = solver.solve(sudoku);
        System.out.println("Solved: " + solvedSudoku);
        assertTrue(solvedSudoku.isSolved());
    }

    private List<List<Integer>> toList(int[][] array) {
        return Stream.of(array).map(cell -> Arrays.stream(cell).boxed().toList()).toList();
    }
}

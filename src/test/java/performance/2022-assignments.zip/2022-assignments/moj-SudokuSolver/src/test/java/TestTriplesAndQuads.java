import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;

/**
 * This class tests the triple and quadruple reduction of the RegionReducer
 */
public class TestTriplesAndQuads {
    private RegionReducer regionReducer = new RegionReducer();

    @Test
    public void testTriple() {
        List<List<Integer>> region = toList(new int[][]{{5}, {1, 7, 8}, {9}, {1, 4, 7}, {3}, {1, 4, 7, 6}, {1, 7, 8}, {1, 7, 8}, {2}});

        List<List<Integer>> reducedRegion = regionReducer.reduce(region);

        List<List<Integer>> expectedRegion = toList(new int[][]{{5}, {1, 7, 8}, {9}, {4}, {3}, {6}, {1, 7, 8}, {1, 7, 8}, {2}});
        assertEquals(expectedRegion, reducedRegion);
    }

    // TODO make example implementation for this
    @Test
    public void testHiddenTriple() {
        List<List<Integer>> region = toList(new int[][]{{5}, {1, 8}, {9}, {1, 4, 7}, {3}, {1, 4, 7, 6}, {1, 7, 8}, {1, 7, 8}, {2}});

        List<List<Integer>> reducedRegion = regionReducer.reduce(region);

        List<List<Integer>> expectedRegion = toList(new int[][]{{5}, {1, 7, 8}, {9}, {4}, {3}, {6}, {1, 7, 8}, {1, 7, 8}, {2}});
        assertEquals(expectedRegion, reducedRegion);
    }

    @Test
    public void testQuadruple() {
        List<List<Integer>> region = toList(new int[][]{{1, 2, 3, 4}, {1, 2, 3, 4}, {1, 2, 3, 4}, {1, 2, 3, 4}, {1, 2, 3, 4, 5, 6, 7, 8, 9}, {1, 2, 3, 4, 5, 6, 7, 8, 9}, {1, 2, 3, 4, 5, 6, 7, 8, 9}, {1, 2, 3, 4, 5, 6, 7, 8, 9}, {1, 2, 3, 4, 5, 6, 7, 8, 9}});

        List<List<Integer>> reducedRegion = regionReducer.reduce(region);

        List<List<Integer>> expectedRegion = toList(new int[][]{{1, 2, 3, 4}, {1, 2, 3, 4}, {1, 2, 3, 4}, {1, 2, 3, 4}, {5, 6, 7, 8, 9}, {5, 6, 7, 8, 9}, {5, 6, 7, 8, 9}, {5, 6, 7, 8, 9}, {5, 6, 7, 8, 9}});
        assertEquals(expectedRegion, reducedRegion);
    }

    private List<List<Integer>> toList(int[][] array) {
        return Stream.of(array).map(cell -> Arrays.stream(cell).boxed().toList()).toList();
    }
}

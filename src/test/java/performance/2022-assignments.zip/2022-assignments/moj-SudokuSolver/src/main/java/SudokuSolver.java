import java.util.stream.IntStream;

/**
 * This class can solve a Sudoku given a good RegionSolver implementation
 */
public class SudokuSolver {
    private RegionReducer regionReducer = new RegionReducer();

    public Sudoku solve(Sudoku sudokuToSolve){
        if(sudokuToSolve.isSolved()){
            return sudokuToSolve;
        }
        String initialValue = sudokuToSolve.toString();
        IntStream.rangeClosed(1,9).forEach(rowNumber -> sudokuToSolve.setRow(rowNumber, regionReducer.reduce(sudokuToSolve.getRow(rowNumber))));
        IntStream.rangeClosed(1,9).forEach(columnNumber -> sudokuToSolve.setColumn(columnNumber, regionReducer.reduce(sudokuToSolve.getColumn(columnNumber))));
        IntStream.rangeClosed(1,9).forEach(blockNumber -> sudokuToSolve.setBlock(blockNumber, regionReducer.reduce(sudokuToSolve.getBlock(blockNumber))));

        if (initialValue.equals(sudokuToSolve.toString())){
            throw new RuntimeException("Couldn't solve sudoku any further: " + sudokuToSolve);
        } else {
            return solve(sudokuToSolve);
        }
    }
}

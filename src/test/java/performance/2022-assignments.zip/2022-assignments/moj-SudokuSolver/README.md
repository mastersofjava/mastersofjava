## Sudoku solver

### Omschrijving voor de Gamemaster

...

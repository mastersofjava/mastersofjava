
public class WeirdArrayBug {
	
	public static boolean equals( Object[] a, Object[] b) {
		return a.equals(b);
	}

}

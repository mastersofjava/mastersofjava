import java.net.URISyntaxException;
import java.net.URL;

public class WeirdUrlBug {
	
	public static boolean equals(URL a, URL b) {
		return a.equals(b);
	}

}

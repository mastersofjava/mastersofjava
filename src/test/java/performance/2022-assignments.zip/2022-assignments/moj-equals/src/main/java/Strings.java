public class Strings {

	private static final String HTML = """
			<html>
			   <body>Hello world!</body>
			</html>

			""";
	
	
	public static String getHtml() {
		return HTML;
	}

}

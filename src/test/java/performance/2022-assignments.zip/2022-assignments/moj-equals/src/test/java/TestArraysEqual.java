import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TestArraysEqual {
	
	
	Object[] a1 = new Object[] { "master", null, new Object[] {"of", "java" }};
	Object[] a2 = new Object[] { "master", null, new String[] {"of", "java" } };

	Object[] b1 = new Object[] { "master", null, null };
	Object[] c1 = new Object[] { "master", null, new String[] {"of", "dotnet" } };

	Object[] d1 = new Object[][] { {"master", "of", "java"}, {"master", "of", "dotnet"} };
	Object[] d2 = new Object[][] { {"master", "of", "java"}, {"master", "of", "dotnet"} };
	
    @Test
	public void testArraysShouldBeEqualNested() {
		assertTrue(WeirdArrayBug.equals(a1,a2));
	}

    @Test
	public void testArraysShouldBeEqualMultiDimensional() {
		assertTrue(WeirdArrayBug.equals(d1,d2));
	}
    
    @Test
	public void testArraysShouldNotBeEqual() {
		assertFalse(WeirdArrayBug.equals(a1,b1));
		assertFalse(WeirdArrayBug.equals(a1,c1));
		assertFalse(WeirdArrayBug.equals(a1,d1));
	}

}

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.net.URL;

import org.junit.Test;

public class TestUrls {
	
	@Test
	public void testUrlsAreDifferent1() throws Exception {
		URL url1 = new URL("https://nljug.org");
		URL url2 = new URL("https://101wasmachines.nl");
		
		assertFalse(WeirdUrlBug.equals(url1, url2));
	}

	@Test
	public void testUrlsAreDifferent2() throws Exception {
		URL url1 = new URL("https://www.first8.nl");
		URL url2 = new URL("https://www.amis.nl");
		
		assertFalse(WeirdUrlBug.equals(url1, url2));
	}


	@Test
	public void testUrlsAreEqual1() throws Exception {
		URL url1 = new URL("https://first8.nl");
		URL url2 = new URL("https://first8.nl");
		
		assertTrue(WeirdUrlBug.equals(url1, url2));
	}

	@Test
	public void testUrlsAreEqual2() throws Exception {
		URL url1 = new URL("https://first8.nl");
		URL url2 = new URL("https://first8.nl:");
		
		assertTrue(WeirdUrlBug.equals(url1, url2));
	}

	@Test
	public void testUrlsAreEqual3() throws Exception {
		URL url1 = new URL("https://first8.nl");
		URL url2 = new URL("https://first8.nl:");
		
		assertTrue(WeirdUrlBug.equals(url1, url2));
	}

	@Test
	public void testUrlsAreEqual4() throws Exception {
		URL url1 = new URL("file:///tmp/ ");
		URL url2 = new URL("file:/tmp/ ");
		
		assertTrue(WeirdUrlBug.equals(url1, url2));
	}

}

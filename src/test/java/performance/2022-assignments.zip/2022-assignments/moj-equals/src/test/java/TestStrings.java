import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestStrings {

	private static final String EXPECTED = 
			"   <html>\n" + 
			"      <body>Hello world!</body>\n" + 
			"   </html>";

	@Test
	public void stringsShouldBeEqual() {
		assertEquals(EXPECTED, Strings.getHtml());
	}

}

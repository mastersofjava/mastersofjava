## JDK17 smorgasbord

### Omschrijving voor de Gamemaster

In JDK 17, de laatste LTS, zitten allerlei nieuwe features. Deze assignment test een paar van de nieuwe features (en een paar oude). Het zijn een reeks mini opdrachtjes achter elkaar.

We gebruiken ook Preview features die ook in JDK18 nog preview zijn...


Voor de URL bug: deze is gevoelig voor veranderingen in de wereld; e.e.a. depend om websites die hetzelfde ip-adres hebben. Check voor aanvang van de wedstrijd dus of de voorbeelden nog kloppen. EN(!) deze moet een actieve internet verbinding hebben, niet geschikt voor de wedstrijd dus :(
## Requirement hell

### Omschrijving voor de Gamemaster

...

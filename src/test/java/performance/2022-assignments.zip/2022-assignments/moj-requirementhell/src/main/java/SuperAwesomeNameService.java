import java.util.List;

/**
 * This class makes the super awesome list of names
 */
public class SuperAwesomeNameService {

    public List<String> doTheThings(List<String> names) {
        // TODO: implement here
        return names;
    }

}

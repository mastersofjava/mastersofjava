import org.junit.Test;

public class Test0 {

    @Test
    public void test0() {
	/*
	 * Ha! You didn't think we were going to do waterfall project management here, did you?
	 * 
	 * No, we are agile! Requirements come as we learn from user feedback. But that doesn't 
	 * mean that we will ignore the deadline of half an hour. 
	 */
    }
	
}
